import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const out=path.resolve('outputs/stock_automl/b2_monthly_distribution_20261016');
const data=JSON.parse(await fs.readFile(path.join(out,'data.json'),'utf8'));
const wb=Workbook.create();
const letter=n=>String.fromCharCode(65+n);
for(const [name,key] of [['月度概览','monthly'],['分位分布','distribution'],['逐笔特征','detail']]){
 const s=wb.worksheets.add(name);s.showGridLines=false;const rows=data[key],keys=Object.keys(rows[0]);
 const last=rows.length+5,end=letter(keys.length-1);
 s.getRange(`A1:${end}${last}`).format={font:{name:'Arial',size:11,color:'#172B4D'},columnWidth:18,rowHeight:24};
 s.getRange('A2').values=[[name]];s.getRange('A2').format.font={size:16,bold:true};
 s.getRange('A3').values=[['2026.01—10.14']];
 s.getRange(`A5:${end}${last}`).values=[keys,...rows.map(r=>keys.map(k=>k==='买入日'?new Date(r[k]+'T00:00:00Z'):(r[k]??null)))];
 s.tables.add(`A5:${end}${last}`,true,'Distribution'+key);
 s.getRange(`A5:${end}5`).format={fill:'#263E59',font:{color:'#FFFFFF',bold:true},horizontalAlignment:'center',rowHeight:30};
 keys.forEach((k,i)=>{
  const range=s.getRange(`${letter(i)}6:${letter(i)}${last}`);
  if(k==='买入日')range.setNumberFormat('yyyy-mm-dd');
  else if(/超100|超10|换手/.test(k))range.setNumberFormat('0.00%');
  else if(/亿|PE中位|市盈率|分位|中位数|最小|最大/.test(k))range.setNumberFormat('#,##0.00');
 });
 if(key==='distribution')rows.forEach((r,i)=>{if(r.指标==='换手率')s.getRange(`F${i+6}:J${i+6}`).setNumberFormat('0.00%');});
 s.freezePanes.freezeRows(5);
 s.getRange('N1:N10').format.columnWidth=82;
 s.getRange('N2:N9').values=[['口径与来源'],['全部特征取D0；按实际买入月统计，同股多笔分别计数。'],['市值和成交额单位亿元，成交量单位亿股；量额均为D0全天。'],['中间50%样本位于下四分位与上四分位之间。'],['PE取TTM；正PE分位数仅统计正值，非正值在概览单列计数。'],['kingdomai.kcrp_stock_pricevaluate：总市值、PE；同日担保券市值补缺。'],['历史市值219/220笔，PE95/220笔；缺失留空，历史估值存在后续更新。'],['日线源为冻结研究样本；四K122笔、五K98笔，不将两者重叠样本合并。']];
}
wb.recalculate();
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?',options:{useRegex:true,maxResults:10},maxChars:500})).ndjson);
for(const name of ['月度概览','分位分布','逐笔特征']){
 const image=await wb.render({sheetName:name,range:name==='月度概览'?'A1:L13':'A1:J13',scale:1});
 await fs.writeFile(path.join(out,name+'.png'),new Uint8Array(await image.arrayBuffer()));
}
await (await SpreadsheetFile.exportXlsx(wb)).save(path.join(out,'四五K_月度规模分布_DIST28_20261016.xlsx'));
