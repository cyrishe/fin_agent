import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const out=path.resolve('outputs/stock_automl/b2_monthly_factors_20261016');
const data=JSON.parse(await fs.readFile(path.join(out,'workbook_data.json'),'utf8'));
const wb=Workbook.create();
const col=n=>{let s='';while(n){n--;s=String.fromCharCode(65+n%26)+s;n=Math.floor(n/26);}return s;};
function table(s,start,records,name){
 const keys=Object.keys(records[0]),last=start+records.length,end=col(keys.length);
 s.getRange(`A${start}:${end}${last}`).values=[keys,...records.map(r=>keys.map(k=>r[k]??null))];
 s.tables.add(`A${start}:${end}${last}`,true,name);
 s.getRange(`A${start}:${end}${start}`).format={fill:'#263E59',font:{color:'#FFFFFF',bold:true},rowHeight:30,horizontalAlignment:'center'};
 s.getRange(`A${start+1}:${end}${last}`).format.rowHeight=23;
 keys.forEach((key,i)=>{
  const c=col(i+1),r=s.getRange(`${c}${start+1}:${c}${last}`);
  if(/收益|高减低|中位$|亏超5率|月差|D0换手/.test(key)&&!key.includes('正PE'))r.setNumberFormat('0.00%;[Red](0.00%);0.00%');
  else if(/亿|PE中位|市盈率|秩相关/.test(key))r.setNumberFormat('#,##0.00');
  else if(/数|缺失|有值|非正|月份$|有效月/.test(key)&&key!=='月份')r.setNumberFormat('0');
 });
 return {keys,last,end};
}
function sheet(name,title,width=17){
 const s=wb.worksheets.add(name);s.showGridLines=false;
 s.getRange('A1:O250').format.font={name:'Arial',size:11,color:'#172B4D'};
 s.getRange('A1:O250').format.columnWidth=width;
 s.getRange('A2').values=[[title]];s.getRange('A2').format.font={size:16,bold:true};return s;
}
const a=sheet('月度特征','月度特征');
a.getRange('A3').values=[['2026.01—10.14']];
table(a,5,data.monthly,'MonthlyFactors');a.freezePanes.freezeRows(5);
a.getRange('O2:O7').values=[['口径与缺项'],['市值、量额、换手和正PE均报中位数。'],['220笔：219笔有市值，95笔有PE。'],['非正PE单列计数，不纳入正PE中位数。'],['10月未完整；未卖出的收益留空。'],['笔均收益不等于资金轮换账户月收益。']];a.getRange('O1:O8').format.columnWidth=65;
const b=sheet('月度分组','月度分组');
b.getRange('A3').values=[['一致性：1—9月']];
table(b,5,data.consistency,'FactorConsistency');
const start=19;const bt=table(b,start,data.groups,'MonthlyGroups');b.freezePanes.freezeRows(start);
for(let i=0;i<data.groups.length;i++){
 const row=start+1+i;b.getRange(`I${row}`).formulas=[[`=IF(AND(E${row}>0,F${row}>0),H${row}-G${row},"")`]];
}
b.getRange('L1:L130').format.columnWidth=25;
b.getRange('O2:O7').values=[['低组≤分界，高组>分界；分界未按收益寻优。'],['至少两组各3笔才计入可比月份。'],['小样本月仍展示，不将缺失当零。'],['相关：月内特征与收益的秩相关。'],['相关需≥6笔、特征≥3个不同值。'],['这些是探索线索，尚未外样本验证。']];b.getRange('O1:O8').format.columnWidth=65;
const c=sheet('逐笔特征','逐笔特征');
c.getRange('A3').values=[['D0特征／D2收益']];
const records=data.detail.map(r=>({...r,买入日:new Date(r.买入日+'T00:00:00Z')}));
const ct=table(c,5,records,'TradeFactors');c.getRange(`A6:A${ct.last}`).setNumberFormat('yyyy-mm-dd');c.freezePanes.freezeRows(5);
c.getRange('L2:L9').values=[['来源说明'],['市值优先估值表，缺失补同日担保券表。'],['担保券市值存在取整；1笔缺失留空。'],['成交量单位亿股；成交额和市值单位亿元。'],['PE为TTM；负值保留，缺失留空。'],['历史估值存在后续更新，未证明当时可见。'],['正PE缺失较多，不能据此制定交易规则。'],['同股多次交易分别计；四五K重复不合并。']];c.getRange('L1:L10').format.columnWidth=70;
wb.recalculate();
for(let i=0;i<data.groups.length;i++){
 const expected=data.groups[i].高减低,actual=b.getRange(`I${start+1+i}`).values[0][0];
 if(expected!==null&&Math.abs(actual-expected)>1e-8)throw new Error('group gap mismatch');
}
console.log((await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!',options:{useRegex:true,maxResults:10},maxChars:600})).ndjson);
for(const [s,range,file] of [[a,'A1:M12','monthly'],[b,'A19:N28','groups'],[c,'A1:J13','detail']]){
 const image=await wb.render({sheetName:s.name,range,scale:1.4});await fs.writeFile(path.join(out,file+'.png'),new Uint8Array(await image.arrayBuffer()));
}
await (await SpreadsheetFile.exportXlsx(wb)).save(path.join(out,'四五K_月度因子观察_F27_20261016.xlsx'));
console.log('Exported: 20 monthly rows, 100 grouped rows, 220 trades.');
